# chess-engine
 Chess engine and interface written in Python.
